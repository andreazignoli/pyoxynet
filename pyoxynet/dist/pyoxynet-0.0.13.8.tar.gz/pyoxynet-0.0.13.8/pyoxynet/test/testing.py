import json
import matplotlib.pyplot as plt

model = utilities.load_tf_model()
df_real, data_dict_real = utilities.draw_real_test()



here=0
